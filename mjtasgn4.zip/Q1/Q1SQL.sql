Select product_name, quantity_per_unit
From products
order by product_name