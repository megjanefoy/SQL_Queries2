Select product_name, unit_price
FROM products
ORDER BY unit_price DESC
LIMIT 10
